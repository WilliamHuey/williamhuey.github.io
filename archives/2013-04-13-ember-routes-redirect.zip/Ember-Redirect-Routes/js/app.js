App = Ember.Application.create();

App.IndexRoute = Ember.Route.extend({
    redirect: function() {
        this.transitionTo('guitars');
    }
});


App.Router.map(function () {
    this.resource('guitars');
});
