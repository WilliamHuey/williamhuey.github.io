﻿;(function ($, window, document, undefined) {
  var pluginName = 'optionsAreOptional',
    defaults;
  var PluginWrapper = function (element, pluginInfo) {
    var Plugin = function () {
      function checkArgs(index) {
        switch (pluginInfo[index]) {
        case 'object':
          //Overwrite defaults if the args item is an object
          Plugin.options = $.extend({}, defaults, pluginInfo.args[index]);
          break;
        case 'function':
          //Store the index of where the function location in args  
          pluginInfo.functionIndex = index;
          break;
        }
      }
      //Check what type of arguments are supplied to 
      //the first and second parameters
      switch (pluginInfo.argsLen) {
      case 1:
        checkArgs(0);
        break;
      case 2:
        checkArgs(0);
        checkArgs(1);
        //Should not have the same parameter types
        if (pluginInfo[0] === pluginInfo[1]) {
          throw ['Can not have the first two parameters of the same type of ', '"',
          pluginInfo[0], '"'].join('');
        }
        break;
      }
    }
    Plugin.prototype = {
      init: function (pluginInfo) {
        //Do Stuff
        this.stuff();
        var $el = $(element);
        //Attaching event listener
        $el.on('optionsAreOptional', function (evt) {
          //Make sure a function exists before executing one
          if (typeof pluginInfo.functionIndex !== 'undefined') {
            //Preserve the event and context
            pluginInfo.args[pluginInfo.functionIndex].call(this, evt);
          }
        });
        //Testing out the event listener
        //Use this upon a certain condition being met
        $el.trigger('optionsAreOptional');
        //Do more stuff here
        this.doMoreStuff();
      },
      stuff: function () {
        //Stuff to be done
      },
      doMoreStuff: function () {
        //Even more stuff to be done
      }
      //Add more functions here
    };
    //Initialize plugin
    Plugin();
    Plugin.prototype.init(pluginInfo);
  }
  $.fn[pluginName] = function () {
    var args = Array.prototype.slice.call(arguments),
      argsLen = args.length,
      pluginInfo = {};
    pluginInfo.argsLen = argsLen;
    pluginInfo.args = args;

    function checkArgs(theItem, index) {
      try {
        //Determine if item is a plain object
        if ($.isPlainObject(theItem)) {
          pluginInfo[index] = 'object';
        }
      } catch (error) {
        throw 'Not a proper object';
      }
      try {
        if ($.isFunction(theItem)) {
          //Determine if item is a function
          pluginInfo[index] = 'function';
        }
      } catch (error) {
        throw 'Not a proper function.';
      }
    }
    return this.each(function () {
      if (!$.data(this, 'plugin_' + pluginName)) {
        //Check for the number of arguments for plugin
        for (var i = 0; i < pluginInfo.argsLen; i++) {
          checkArgs(pluginInfo.args[i], i);
        }
        $.data(this, 'plugin_' + pluginName, new PluginWrapper(this, pluginInfo));
      }
    });
  };
})(jQuery, window, document);