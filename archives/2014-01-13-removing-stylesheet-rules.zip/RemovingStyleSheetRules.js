
//Retrieve sheet from css dom element
var mainStylesHtml = document.getElementById('mainStyles'),
  mainStyles;

if (mainStylesHtml.sheet) {
  mainStyles = mainStylesHtml.sheet
} else if (mainStylesHtml.styleSheet) {
  mainStyles = mainStylesHtml.styleSheet
}

//Get rules off the sheet object
var mainRules;
if (mainStyles.cssRules) {
  mainRules = mainStyles.cssRules;
} else if (mainStyles.rules) {
  mainRules = mainStyles.rules;
}

//Notes for Rules
//http://help.dottoro.com/ljnefpqb.php

//Iterate through the stylesheet rules
var theKey;
for (key in mainRules) {
  //Make sure key is valid
  if (typeof mainRules[key].selectorText != 'undefined') {
    //The string will be the name of the selector that is to be removed
    if ("#paragraph-is-orange-when-hover:hover" == (mainRules[key].selectorText)) {
      //Coercing the string key to a number key
      theKey = key * 1;
    }
  }
}

//Remove the rule
if (mainStyles.deleteRule) {
  mainStyles.deleteRule(theKey);
} else {
  mainStyles.removeRule(theKey);
}

//Notes for Deleting Rules
//deleteRule: http://help.dottoro.com/ljcihbgl.php
//removeRule: http://help.dottoro.com/ljdupbal.php

//Note: Chrome-based browser only allow stylesheet manipulation
//if the parameter "--allow-file-access-from-files" is set.
//http://www.chrome-allow-file-access-from-file.com/
