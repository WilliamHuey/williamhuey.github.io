var fs = require('fs'),
  byline = require('byline');

var stream = fs.createReadStream('./war-and-peace.txt');
stream = byline.createStream(stream);

var counter = 0;
console.time('time');

stream.on('data', function(line) {
  counter++;
}).on('end', function() {
  console.log('Read: ' + counter + ' lines');
  console.timeEnd('time');
});