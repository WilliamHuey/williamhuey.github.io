 var es = require('event-stream'),
   fs = require('fs');

 var counter = 0;
 console.time('time');

 fs.createReadStream('./war-and-peace.txt')
   .pipe(es.split())
   .pipe(es.map(function(line, cb) {
     counter++;
     cb(null, line);
   })).on('end', function() {
     console.log('Read: ' + counter + ' lines');
     console.timeEnd('time');
   });