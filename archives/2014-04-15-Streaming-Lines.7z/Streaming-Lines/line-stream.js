var linestream = require('line-stream'),
  fs = require('fs');

var counter = 0;
console.time('time');

var s = linestream();

s.on('data', function(line) {
  counter++;
}).on('end', function() {
  console.log('Read: ' + counter + ' lines');
  console.timeEnd('time');
});

fs.createReadStream('./war-and-peace.txt').pipe(s);