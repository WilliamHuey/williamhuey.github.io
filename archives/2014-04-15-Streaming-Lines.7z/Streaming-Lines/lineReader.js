var lineReader = require('line-reader');

var counter = 0;
console.time('time');

lineReader.eachLine('./war-and-peace.txt', function(line, last) {
  counter++;
}).then(function() {
  console.log('Read: ' + counter + ' lines');
  console.timeEnd('time');
});