var lr = new(require('line-by-line'))('./war-and-peace.txt');

var counter = 0;
console.time('time');

lr.on('error', function(err) {
  // 'err' contains error object
}).on('line', function(line) {
  counter++;
  // 'line' contains the current line without the trailing newline character.
  //console.log(counter);

}).on('end', function() {
  console.log('Read: ' + counter + ' lines');
  console.timeEnd('time');
});