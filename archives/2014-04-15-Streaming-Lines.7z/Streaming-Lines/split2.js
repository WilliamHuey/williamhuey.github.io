var split2 = require('split2'),
  fs = require('fs');

var counter = 0;
console.time('time');

fs.createReadStream('./war-and-peace.txt')
  .pipe(split2()) 
  .on('data', function(line) {
    counter++;
  })
  .on('end', function() {
    console.log('Read: ' + counter + ' lines');
    console.timeEnd('time');
  });